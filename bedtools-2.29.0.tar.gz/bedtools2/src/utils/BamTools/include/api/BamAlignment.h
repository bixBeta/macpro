#include <htslib/sam.h>
#include <SamHeader.hpp>
#include <BamAlignment.hpp>
