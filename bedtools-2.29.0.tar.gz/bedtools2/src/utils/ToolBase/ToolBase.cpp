#include "ToolBase.h"

// All methods are currently purely abstract, so this file is only a placeholder for any future
// methods that may be added.
